
<head>
<link rel="StyleSheet" href="style.css" type="text/css">
</head>

<!-- logo -->

<?php include_once("html_header.php"); ?>


<br><br><br><br><br><br>

<center>
<b>Not started yet!</b><br>
<a href="index.php">Go to beginning</a><br>
</center>

<?php include("html_footer.php");?>
