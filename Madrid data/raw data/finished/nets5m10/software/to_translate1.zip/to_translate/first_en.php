<!-- Starting page of experiment with welcome message.
     After pressing the button players are redirected to login page -->


<head>
<link rel="StyleSheet" href="style.css" type="text/css">
</head>

<!-- logo -->

<?php include_once("html_header.php"); ?>

<iframe src="http://free.timeanddate.com/clock/i1ih10sb/n141/tles4/fs16/ftb/th1/ts1" frameborder="0" width="43" height="21" align="right"></iframe>


Welcome to the experiment!

<br><br><br>

Please, do not communicate with other participants. Turn off your phone and put all your belongings away.

<br><br>

If you need help, please, raise your hand.

<br><br>

Please, DO NOT PRESS THE BUTTON until the experimenters tell you to do so.

<br><br>

You received an envelop with the username and password, a form for your participation and bank details, and the instructions. 

<br><br> 
Your username is known only to you, not even the experimenters know who is who in the experiment. 
Keep the paper safe. At the end of the experiment you will need to show it to us, so we can verify how much money you earned. 
<br><br> 
You can already fill in the form you received with your name and bank details.

At the end of the experiment you will see on the screen the amount of money you earned. 
Write this sum on the form and wait for the experimenter to call you.

<br><br>
After logging in, you will be introduced to the experiment. 
At the end of the instructions there will be a small test to check whether you understand the experiment. 
You also have a written copy of the instructions if you want to check something during the game.

<br><br>

<form name="form1" method="post" action="checkdaemon.php" >
Click <input type="submit" value="here" class="btn" name="submit"> to continue.
</form><br />
<?php include("html_footer.php")?>