
<head>
<link rel="StyleSheet" href="style.css" type="text/css">
</head>

<!-- logo -->

<?php include_once("html_header.php"); ?>


<br><br><br><br><br><br>

<center>
<b>Pas encore commencé !</b><br>
<a href="index.php">Allez au début</a><br>
</center>

<?php include("html_footer.php");?>
