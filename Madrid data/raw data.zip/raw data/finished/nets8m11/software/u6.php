<?php
$korisnik=usuario6;
$sifra=pimienta;
include_once("login.php");
?>
