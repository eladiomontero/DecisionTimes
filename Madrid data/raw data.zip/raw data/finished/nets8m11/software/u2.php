<?php
$korisnik=usuario2;
$sifra=avispa;
include_once("login.php");
?>
