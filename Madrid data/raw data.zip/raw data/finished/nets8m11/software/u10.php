<?php
$korisnik=usuario10;
$sifra=capital;
include_once("login.php");
?>
