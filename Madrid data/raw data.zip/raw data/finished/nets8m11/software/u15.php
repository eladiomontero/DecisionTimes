<?php
$korisnik=usuario15;
$sifra=oveja;
include_once("login.php");
?>
