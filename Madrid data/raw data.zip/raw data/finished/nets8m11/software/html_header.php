<head>
<link rel="StyleSheet" href="style.css" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

</head>


<basefont face="Tahoma,Arial,Helvetica,sans-serif">

<center>
<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%" HEIGHT="100%">
<colgroup>
    <col style="width: 45%" />
    <col style="width: 10%" />
    <col style="width: 45%" />
</colgroup>
	<TR VALIGN=center ALIGN=LEFT BGCOLOR="#FFFFFF" HEIGHT=100>
	        <TD VALIGN=center>
	          <IMG border=0 SRC="./pics/logo-vub-large1.png">
	        </TD> 

                <TD valign=bottom align=center rowspan=2>
                  <IMG SRC="./pics/brussels.png" BORDER=0 HEIGHT=160>
                </TD>

	        <TD VALIGN=center align=right>
                   <IMG border=0 SRC="./pics/ulblogo.jpeg">
                </TD> 
	                                          
	</TR>


	<TR bgcolor="#A2A88E" HEIGHT=20>  
        	<TD align=left> 
<!--        	<P><FONT face="Arial" size=1 class="small" COLOR="#14160e"> ORSEE </FONT> -->
        	</TD>
        	<TD align=right>
<!--        	<P><FONT face="Arial" size=1 class="small" COLOR="#14160e"> ONLINE RECRUITMENT SYSTEM FOR ECONOMIC EXPERIMENTS</FONT> -->                
        	</TD>
        </TR>   	                                                                
	<TR bgcolor="#14160E" valign=center align=center HEIGHT=30>
	    <TD colspan=3>
        	<P><FONT face="Aliel Black" size=5 COLOR="#ffffff"> <b>Brussels Experimental Economics Laboratory </b></FONT>
	    </TD>
	</TR>
	<TR>
	    <TD VALIGN=TOP ALIGN=LEFT colspan=3>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%" HEIGHT="100%" bgcolor="#F9F9Ef">
                    <TR>
                        <TD width=10%> </TD>
                        <TD width=80% valign=top>
	                                                                                          

