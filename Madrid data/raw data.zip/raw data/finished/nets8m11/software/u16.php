<?php
$korisnik=usuario16;
$sifra=mantequilla;
include_once("login.php");
?>
