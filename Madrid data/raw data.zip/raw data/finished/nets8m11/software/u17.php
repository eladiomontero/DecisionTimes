<?php
$korisnik=usuario17;
$sifra=gallina;
include_once("login.php");
?>
