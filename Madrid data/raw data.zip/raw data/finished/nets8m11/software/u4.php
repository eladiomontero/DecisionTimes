<?php
$korisnik=usuario4;
$sifra=consumidor;
include_once("login.php");
?>
