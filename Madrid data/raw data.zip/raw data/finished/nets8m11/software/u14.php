<?php
$korisnik=usuario14;
$sifra=rata;
include_once("login.php");
?>
