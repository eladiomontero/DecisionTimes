<?php
$korisnik=usuario3;
$sifra=cremallera;
include_once("login.php");
?>
