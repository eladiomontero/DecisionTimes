<?php
$korisnik=usuario5;
$sifra=manga;
include_once("login.php");
?>
