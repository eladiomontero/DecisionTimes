<?php
$korisnik=usuario13;
$sifra=loro;
include_once("login.php");
?>
