<?php
$korisnik=usuario1;
$sifra=margarina;
include_once("login.php");
?>
