<?php
$korisnik=usuario12;
$sifra=carne;
include_once("login.php");
?>
