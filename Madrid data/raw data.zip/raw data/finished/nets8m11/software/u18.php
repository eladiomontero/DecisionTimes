<?php
$korisnik=usuario18;
$sifra=franela;
include_once("login.php");
?>
