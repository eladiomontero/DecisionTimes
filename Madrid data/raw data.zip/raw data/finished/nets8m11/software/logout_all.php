<?php  
  session_start();
  session_destroy();  
?>
<script type="text/javascript">
top.location="index.php";
</script>

<!-- Logout function for all players, used during the testing phase -->