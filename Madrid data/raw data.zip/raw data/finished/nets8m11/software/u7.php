<?php
$korisnik=usuario7;
$sifra=quiebra;
include_once("login.php");
?>
