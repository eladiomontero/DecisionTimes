
<head>
<link rel="StyleSheet" href="style.css" type="text/css">
</head>

<!-- logo -->

<?php include_once("html_header.php"); ?>


<br><br><br><br><br><br>

<center>
<b>Nog niet gestart!</b><br>
<a href="index.php">Ga terug naar het begin</a><br>
</center>

<?php include("html_footer.php");?>
