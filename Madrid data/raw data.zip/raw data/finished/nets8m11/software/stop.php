<!-- Stops the experiment, by setting total rounds number to 0 -->

<?php
file_put_contents('data/roundsnumber', "0");
?>

<script type="text/javascript">
top.location="index.php";
</script>
