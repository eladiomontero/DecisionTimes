#!/bin/bash
# resetting all the parameter to the values they should have before the experiment is started
# without erasing the files with data
    cd software/data
    python cleanfiles.py

