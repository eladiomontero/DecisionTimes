

Payoffs: T=4, R=3, P=1, S=0
These are session with the fix partners: ['s1m5','s2m5','s4m8','s8n3','s9n3','s10n5']
These are the session where partners are changed in every round: ['s5m20','s6m22','s7m22','s11n9','s12n11','s13n12']


Payoff: T=4, R=3, P=0, S=0
In this session they played weak PD with fix partner: ['s3m7']
